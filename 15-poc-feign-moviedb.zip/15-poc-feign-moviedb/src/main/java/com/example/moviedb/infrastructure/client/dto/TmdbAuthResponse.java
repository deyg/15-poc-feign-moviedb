package com.example.moviedb.infrastructure.client.dto;

public class TmdbAuthResponse {

    private String accessToken;
    private long expiresIn;

    public TmdbAuthResponse() {
    }

    public TmdbAuthResponse(String accessToken, long expiresIn) {
        this.accessToken = accessToken;
        this.expiresIn = expiresIn;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public long getExpiresIn() {
        return expiresIn;
    }
}
