package com.example.moviedb.infrastructure.client;

import com.example.moviedb.infrastructure.client.dto.TmdbAuthRequest;
import com.example.moviedb.infrastructure.client.dto.TmdbAuthResponse;
import com.example.moviedb.infrastructure.config.TmdbAuthFeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

/**
 * Feign "limpo" usado apenas para obter token da TMDB.
 */
@FeignClient(
        name = "tmdbAuthClient",
        url = "${tmdb.auth.url}",
        configuration = TmdbAuthFeignConfig.class
)
public interface TmdbAuthFeignClient {

    @PostMapping("/auth/token")
    TmdbAuthResponse getToken(TmdbAuthRequest request);

}
