package com.example.moviedb.infrastructure.service;

import com.example.moviedb.infrastructure.client.TmdbAuthFeignClient;
import com.example.moviedb.infrastructure.client.dto.TmdbAuthRequest;
import com.example.moviedb.infrastructure.client.dto.TmdbAuthResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Serviço responsável por obter e cachear o token vindo da própria TMDB.
 */
@Service
public class AuthTokenService {

    private final TmdbAuthFeignClient authClient;
    private final String apiKey;
    private final String clientId;
    private final String clientSecret;

    private volatile String cachedToken;
    private volatile long expiresAtMillis;

    public AuthTokenService(
            TmdbAuthFeignClient authClient,
            @Value("${tmdb.api.key:}") String apiKey,
            @Value("${tmdb.client-id:}") String clientId,
            @Value("${tmdb.client-secret:}") String clientSecret) {
        this.authClient = authClient;
        this.apiKey = apiKey;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    public String getToken() {
        long now = System.currentTimeMillis();
        if (cachedToken != null && now < expiresAtMillis) {
            return cachedToken;
        }

        TmdbAuthRequest request = new TmdbAuthRequest(apiKey, clientId, clientSecret);
        TmdbAuthResponse response = authClient.getToken(request);

        if (response == null || response.getAccessToken() == null) {
            throw new IllegalStateException("Não foi possível obter token da TMDB");
        }

        this.cachedToken = response.getAccessToken();

        long ttlMillis = (response.getExpiresIn() > 0 ? response.getExpiresIn() : 300) * 1000L;
        this.expiresAtMillis = now + ttlMillis - 30_000;

        return this.cachedToken;
    }
}
