package com.example.moviedb.infrastructure.config;

import feign.Logger;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuração específica para o Feign que obtém o token da TMDB.
 * Não deve registrar interceptors de autenticação aqui.
 */
@Configuration
public class TmdbAuthFeignConfig {

    @Bean
    public Logger.Level feignLoggerLevel() {
        return Logger.Level.BASIC;
    }

}
