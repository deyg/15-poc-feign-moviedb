package com.example.moviedb.infrastructure.config;

import com.example.moviedb.infrastructure.service.AuthTokenService;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;

/**
 * Configuração para os clientes Feign que já consomem a API protegida da TMDB.
 * Aqui registramos o interceptor que injeta o Bearer Token.
 */
@Configuration
public class TmdbFeignConfig {

    @Bean
    public RequestInterceptor tmdbAuthInterceptor(AuthTokenService authTokenService) {
        return new RequestInterceptor() {
            @Override
            public void apply(RequestTemplate template) {
                String token = authTokenService.getToken();
                if (token != null && !token.isBlank()) {
                    template.header(HttpHeaders.AUTHORIZATION, "Bearer " + token);
                }
            }
        };
    }
}
