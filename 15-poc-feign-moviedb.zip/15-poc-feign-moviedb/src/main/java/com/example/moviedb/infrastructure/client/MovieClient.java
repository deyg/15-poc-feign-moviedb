package com.example.moviedb.infrastructure.client;

import com.example.moviedb.infrastructure.config.TmdbFeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(
        name = "tmdbMovieClient",
        url = "${tmdb.api.url}",
        configuration = TmdbFeignConfig.class
)
public interface MovieClient {

    @GetMapping("/movie/popular")
    Object getPopular(@RequestParam("page") int page);

}
