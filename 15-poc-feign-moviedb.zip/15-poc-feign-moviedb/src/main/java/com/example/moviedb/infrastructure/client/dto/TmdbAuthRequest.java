package com.example.moviedb.infrastructure.client.dto;

public class TmdbAuthRequest {

    private String apiKey;
    private String clientId;
    private String clientSecret;

    public TmdbAuthRequest() {
    }

    public TmdbAuthRequest(String apiKey, String clientId, String clientSecret) {
        this.apiKey = apiKey;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
    }

    public String getApiKey() {
        return apiKey;
    }

    public String getClientId() {
        return clientId;
    }

    public String getClientSecret() {
        return clientSecret;
    }
}
