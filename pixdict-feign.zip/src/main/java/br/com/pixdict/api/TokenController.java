package br.com.pixdict.api;

import br.com.pixdict.domain.TokenResponse;
import br.com.pixdict.infrastructure.feign.DictAuthFeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TokenController {

    private final DictAuthFeignClient dictAuthFeignClient;

    public TokenController(DictAuthFeignClient dictAuthFeignClient) {
        this.dictAuthFeignClient = dictAuthFeignClient;
    }

    @GetMapping("/dict/token")
    public TokenResponse getToken() {
        return dictAuthFeignClient.getToken();
    }
}
