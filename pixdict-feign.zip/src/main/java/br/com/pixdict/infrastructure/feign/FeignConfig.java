package br.com.pixdict.infrastructure.feign;

import feign.Logger;
import feign.RequestInterceptor;
import feign.form.FormEncoder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.openfeign.support.SpringEncoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;

@Configuration
public class FeignConfig {

    @Value("${dict.client.id}")
    private String clientId;

    @Value("${dict.client.secret}")
    private String clientSecret;

    @Bean
    public RequestInterceptor requestInterceptor() {
        return requestTemplate -> {
            requestTemplate.header("Content-Type", MediaType.APPLICATION_FORM_URLENCODED_VALUE);
            requestTemplate.header("x-itau-flowID", "6bb2e7e2-ecf2-4604-8663-acfaf140f7c8");
            requestTemplate.header("x-itau-correlationID", "c002ee06-afd8-40da-bda0-581e07cb2919");
            requestTemplate.header("Cache-Control", "no-cache");

            String body = "grant_type=client_credentials" +
                    "&client_id=" + clientId +
                    "&client_secret=" + clientSecret;
            requestTemplate.body(body);
        };
    }

    @Bean
    public feign.codec.Encoder feignFormEncoder() {
        return new FormEncoder(new SpringEncoder(() -> null));
    }

    @Bean
    Logger.Level feignLoggerLevel() {
        return Logger.Level.FULL;
    }
}
