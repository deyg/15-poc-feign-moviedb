package br.com.pixdict.infrastructure.feign;

import br.com.pixdict.domain.TokenResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

@FeignClient(
        name = "dictAuthClient",
        url = "${dict.auth.url}",
        configuration = FeignConfig.class
)
public interface DictAuthFeignClient {

    @PostMapping
    TokenResponse getToken();
}
